/**
 *  Lado do cliente.
 *  Solução do Problema dos Barbeiros Sonolentos que implementa o modelo cliente-servidor
 *  de tipo 2 (replicação do servidor) com lançamento estático dos threads barbeiro.
 *  A comunicação baseia-se em passagem de mensagens sobre sockets usando o protocolo TCP.
 */

package clientSide;

